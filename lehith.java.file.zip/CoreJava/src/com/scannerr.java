package com;
import java.util.Scanner;
public class scannerr {
	public static void main(String[]arg) {
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt ();
		System.out.println(a);
		
	}

}
