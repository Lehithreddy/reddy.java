package com;
public class withoutreturnwithoutarg {
	public static void add() {
		int a=10;
		int b=20;
		int res=a+b;
		System.out.println(res);
	}
	public static void main(String[] args) {
		add();
		
	}
}
