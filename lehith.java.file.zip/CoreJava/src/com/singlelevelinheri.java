package com;

public class singlelevelinheri {

}
