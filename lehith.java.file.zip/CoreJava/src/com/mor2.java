package com;
public class mor2 {
	public void whatsappversion() {
		System.out.println("version 2 singleticks+doubleticks");
	}
	public static void main(String[] args) {
		mor2 m=new mor2();
		m.whatsappversion();
		
	}

}
