package com;

import java.io.File;


public class fileclass {
	public static void main(String[] args) {
		File F=new File("hii.text");
		try {
			boolean res=F.createNewFile();
			System.out.println(res);
			System.out.println(F.getAbsoluteFile());
			
		}
		catch(Exception e) {
			System.out.println("its not true");
		}
	}

}
