package com;

public class firstcode {
	int a=10;
	
	public static void main(String[] arg) {
		int a=20;
		
		
		System.out.println(a);
		
		System.out.println(a);
	}
		


}
