package com;

public class vowels_or_not {

}
