package com;

public class arthimetic extends Exception {

}
