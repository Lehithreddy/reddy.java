package com;

public class interfacedd {
	public void dd() {
		System.out.println("dd");
	}

}
