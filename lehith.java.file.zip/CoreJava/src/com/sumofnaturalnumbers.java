package com;

public class sumofnaturalnumbers {
	public static void main(String[]arg) {
	
	}

}
