package com;

public class natural {

}
