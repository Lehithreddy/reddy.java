package com;

public class linearsearch {
	public static void main(String[] args) {
		int[] arr= {5,3,8,4,2};
		int target=4;
		boolean found=false;
		for(int i=0;i<=arr.length-1;i++) {
			if(arr[i]==target) {
				System.out.println("found at index:"+i);
			found=true;
				break;
				
				
			}
		}
		if(!found) {
			System.out.println("not found");
		}
		
	}

}
