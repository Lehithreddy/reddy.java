package com;

public class interfacea {

}
