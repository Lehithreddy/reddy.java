package com;

public class nullpointerexception {
	public static void main(String[] args) {
		String hi=null;
		try {
			System.out.println(hi.length());
		}
		catch(Exception e) {
			System.out.println("its null");
		}
	}

}
