package com;

public class interfacec {

}
