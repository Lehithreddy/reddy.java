package com;
public class singlesuperclass {
	int a;
	int b;
	public void display() {
		System.out.println(a);
		System.out.println(b);
		
	}
}
