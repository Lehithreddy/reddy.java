package programs;
import java.util.Scanner;
public class vowel_not {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		char ch=Sc.next().charAt(0);
		if(ch == 'a'|| ch == 'A'|| ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' ||ch=='O'||ch=='u'|| ch == 'U')
		{
			System.out.println("ch is vowel");
		}
			else 
			{
				System.out.println("ch is not vowel");
			
			}
			
		}
	}

	


