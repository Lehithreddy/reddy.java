package com;
import java.util.HashMap;
public class hashmap {
	public static void main(String[] args) {
		HashMap<Integer,String>Map=new HashMap<>();
		Map.put(1,"apple");
		Map.put(2,"BANANA");
		Map.put(3,"CHERRY");
		Map.put(2,"MANGO");
		System.out.println(Map.get(1));
		System.out.println(Map.get(2));
		System.out.println(Map.containsKey(3));
		System.out.println(Map.containsValue("banana"));
		Map.remove(3);
		for(Int	eger key:Map.keySet()) {
			System.out.println(key+"-->"+Map.entrySet());
		}
	}

}
