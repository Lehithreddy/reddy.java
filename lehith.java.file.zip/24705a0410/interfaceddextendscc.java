package com;

public class interfaceddextendscc {
	public void dd() {
		System.out.println("d");
	}
	

}
