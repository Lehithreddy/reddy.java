package com;
public class withoutreturnwithoutarg {
	public static void sub() {
		int a=10;
		int b=2;
		int res=a-b;
		System.out.println(res);
	}
	public static void main(String[] args) {
		sub();
		
	}
}
