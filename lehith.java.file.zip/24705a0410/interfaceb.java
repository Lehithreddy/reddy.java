package com;

public class interfaceb extends interfacea{
	public void b() {
		
	}

}
