package com;
import java.util.Scanner;
public class vowel {
	public static void main(String[]arg) {
		Scanner Sc=new Scanner(System.in);
		char ch=Sc.next().charAt(0);
		if(ch == 'a'|| ch == 'A'|| ch == 'e' || ch == 'E' || ch == 'i' || ch == 'I' || ch == 'o' ||ch=='O'||ch=='u'|| ch == 'U')
		{
			System.out.println("ch is vowel");
			
		}
	}
	

}
 