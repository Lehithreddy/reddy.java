package com;

import java.io.Flushable;
import java.io.PrintStream;

public class filewrite {
	public static void main(String[] args) {
		try {
			filewrite fw= new filewrite();
			 fw.write("bashimp");
	            fw.flush();
	            fw.close();
			
			System.out.println("content is share to file");
		}
		catch(Exception e) {
			System.out.println("cant write");
		}
		
	}

	private void flush() {
		// TODO Auto-generated method stub
		
	}

	private void close() {
		// TODO Auto-generated method stub
		
	}

	private void write(String string) {
		// TODO Auto-generated method stub
		
	}

}
