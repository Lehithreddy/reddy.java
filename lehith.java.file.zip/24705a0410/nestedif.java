package com;
import java.util.Scanner;
public class nestedif {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		int n=Sc.nextInt();
		if( n % 3 == 0) {
			
				System.out.println("number is divisible by 3 and 9");
				else {
					System.out.println("number is  not divisible by 3 and 9");
					
				}
			}
		}
		
	}


