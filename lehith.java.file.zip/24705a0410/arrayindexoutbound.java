package com;

public class arrayindexoutbound {
	public static void main(String[] args) {
		
	int[] arr= {1,2,3,4,5};
	try {
		int res= arr[4];
		System.out.println(res);
	}
	catch( Exception e) {
	System.out.println("array value is not present");
	

	}
	}
}


