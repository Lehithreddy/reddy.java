package com;
public class greates {
	public static void main(String[] args) {
		int a=0;
		int b=0;
		int c=0;
		if(a>=b&&a>=c) {
			System.out.println("gretest is"+a);
		}
		else if(b>=a&&b>=c) {
			System.out.println("gretest is"+a);
		}
						else if(c>=a&&c>=b) {
				System.out.println("gretest is"+c);
				
			}
			else {
				System.out.println("enter number");
				
			}
	}
}
		
		
	


