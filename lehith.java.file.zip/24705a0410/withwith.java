package com;
public class withwith {
	public static int mul(int a,int b) {
		return a*b;
	}
		public static void main(String[]arg) {
			int result=mul(4,7);
			System.out.println(result);
		}
		
	}


