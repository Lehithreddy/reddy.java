package com;



public class finalinterfacesee {
	public void cc() {
		System.out.println("c");

	}
	public void dd() {
		System.out.println("d");

	}
	public void ee() {
		System.out.println("e");

	}
	public static void main(String[] args) {
		finalinterfacesee f=new finalinterfacesee();
		f.cc();
		f.dd();
		f.ee();
	}
	

}
