package com;
import java.util.Scanner;
public class simpleif {
	public static void main(String[] arg) {
		Scanner Sc=new Scanner(System.in);
		int a=10;
		if (a % 1 == 0) {
			System.out.println("it is prime");
			
		}
		
	}

}
