package com;
import java.util.Scanner;
public class finallymethod {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		try {
			int n= Sc.nextInt();
			System.out.println(n);
		}
		catch(Exception e) {
			System.out.println("its not match");
		}
			finally {
				System.out.println("your code is excecuted");
				
			}
		}
	}

