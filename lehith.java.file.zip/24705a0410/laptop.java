package com;
public class laptop {
	private String name;
	private String model;
	private int memory;
	private int ram;
	private int cost;
	public laptop() {
		
	}
	public laptop(String name,String model,int memory,int ram,int cost) {
		this.name=name;
		this.model=model;
		this.memory=memory;
		this.ram=ram;
		this.cost=cost;
		
	}
	public void setname(String name) {
		this.name=name;
	}
	public String getname() {
		return name;
	}
	public void setmodel(String model) {
		this.model=model;
	}
	public String getmodel() {
		return model;
	}
	public void setmemory(int memory) {
		this.memory=memory;
	}
	public int getmemory() {
		return memory;
	}
	public void setram(int ram) {
		this.ram=ram;
	}
	public int getram() {
		return ram;
	}
	public void setcost(int cost) {
		this.cost=cost;
	}
	public int getcost() {
		return cost;
	}
	public void display() {
		System.out.println("name of the laptop:"+getname());
		System.out.println("model of the laptop:"+getmodel());
		System.out.println("memory of the laptop:"+getmemory());
		System.out.println("ram of the laptop:"+getram());
		System.out.println("cost of the laptop:"+getcost());
	}
	public static void main(String[] args) {
		System.out.println("laptop details");
		laptop l=new laptop();
		l.setname("dell");
		l.setmodel("acto");
		l.setmemory(64);
		l.setram(4);
		l.setcost(87000);
		l.display();
		System.out.println("=-=-=-=-=-=-=-=-=-=");
		System.out.println("details of another laptop");
	
	laptop l1=new laptop();
	
	l1.setname("apple");
	l1.setmodel("hexa");
	l1.setmemory(128);
	l1.setram(16);
	l1.setcost(85400);
	l1.display();
	System.out.println("=-=-=-=-=-=-=-=-=-=");
	}
	
	
	

}
