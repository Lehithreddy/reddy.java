package com;
public class finalimplements {
	public void c() {
		System.out.println("c");
	}
	public void d() {
		System.out.println("d");
	}
	public void e() {
		System.out.println("e");
	}
	public static void main(String[] args) {
		finalimplements f=new finalimplements();
		f.c();
		f.d();
		f.e();
	}



}
