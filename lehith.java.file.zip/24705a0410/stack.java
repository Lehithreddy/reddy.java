package com;
import java.util.Stack;
public class stack {
	public static void main(String[] args) {
		Stack<Integer>Stack=new Stack<>();
		Stack.push(10);
		Stack.push(20);
		Stack.push(30);
		System.out.println("stack:"+Stack);
		System.out.println("top element:"+Stack.peek());
		System.out.println("popped:"+Stack.pop());
		System.out.println("stack after pop:"+Stack);
		System.out.println("position of 10:"+Stack.search(10));
		System.out.println("is stack empty?"+Stack.empty());
		System.out.println("size:"+Stack.size());
		
	}

}
