package com;

public class reverse_array {
	public static void main(String[] args) {
		int[]arr= new int[10];
		arr[0]=1;
		arr[1]=2;
		arr[2]=3;
		arr[3]=4;
		arr[4]=5;
		arr[5]=6;
		arr[6]=7;
		arr[7]=8;
		
			
		

		System.out.println("reverse array:");
		for(int i=arr.length-1;i>=0;i--) {
			System.out.println(arr[i]+" ");
		}
		
	}

}
