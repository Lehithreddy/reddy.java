package com;
public class book{
	private String title;
	private String author;
	private int  pages;
	private int cost;
	public book() {
		
	}
	 public Book(String title1, String author, int pages, int cost) {
	title=title1;
	this.author=author;
	this.pages=pages;
	this.cost=cost;
	
	
		
	}
public void settitle(String title) {
	this.title=title;
}
public String gettitle() {
	return title;
}public void setauthor(String author) {
	this.author=author;
}
public String getauthor() {
	return author;
}
public void setpages(int pages) {
	this.pages=pages;
}
public int getpages() {
	return pages;
}
public void setcost(int cost) {
	this.cost=cost;
}
public int getcost() {
	return cost;
}
public void display() {
	System.out.println("name of the book:"+gettitle());
	System.out.println("author of the book:"+getauthor());
	System.out.println("pages of the book:"+getpages());
	System.out.println("cost of the book:"+getcost());
}

			
	

}

