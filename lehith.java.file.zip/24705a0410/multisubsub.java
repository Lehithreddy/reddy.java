package com;
public class multisubsub extends multisub {
	public void car2() {
		System.out.println("bmw m3");
		
	}
	public static void main(String[] args) {
		multisubsub mss=new multisubsub();
		mss.car2();
		mss.car1();
		mss.car();
	}

}
