package com;
import java.util.Scanner;
public class inputmismatch {
	public static <scanner> void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		try {
			int n=Sc.nextInt();
			System.out.println(n);
		}
		catch(Exception e) {
			System.out.println("it not match");
			
			
		}
	}

}
