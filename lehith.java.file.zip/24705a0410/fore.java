package com;
import java.util.Scanner;
public class fore {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		 for (int i = 10; i >= 1; i--) {
			System.out.println(i);
		}
		
	}

}
