package com;
public class booke {
	private String title;
	private String author;
	private int  pages;
	private int cost;
	public booke() {
		
	}
	public booke(String title, String author, int pages, int cost) {
	this.title=title;
	this.author=author;
	this.pages=pages;
	this.cost=cost;
	
	
		
	}
public void settitle(String title) {
	this.title=title;
}
public String gettitle() {
	return title;
}public void setauthor(String author) {
	this.author=author;
}
public String getauthor() {
	return author;
}
public void setpages(int pages) {
	this.pages=pages;
}
public int getpages() {
	return pages;
}
public void setcost(int cost) {
	this.cost=cost;
}
public int getcost() {
	return cost;
}
public void display() {
	System.out.println("name of the book:"+gettitle());
	System.out.println("author of the book:"+getauthor());
	System.out.println("pages of the book:"+getpages());
	System.out.println("cost of the book:"+getcost());
}
public static void main(String[]arg) {
	System.out.println("booke details");
	booke m=new booke();
	m.settitle("avengers");
	m.setauthor("author");
	m.setpages(760);
	m.setcost(65);
	m.display();
	System.out.println("------------");
	
	
	
	
}

			
	

}

