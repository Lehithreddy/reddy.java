package com;

 class node {
	int data;
	node next;
	node(int new_data){
		this.data=new_data;
		this.next=null;
	
	}

}
public class singlelinkedlist {
	public static void traveselist(node head) {
		while(head!=null) {
			System.out.println(head.data+"");
			head=head.next;
			
		}
		System.out.println();
		
	}
	public static void main(String[] args) {
		node head=new node(10);
		head.next=new node(20);
		head.next.next=new node(30);
		head.next.next.next=new node(70);
		traveselist(head);
		
	}
}
	
		
	
