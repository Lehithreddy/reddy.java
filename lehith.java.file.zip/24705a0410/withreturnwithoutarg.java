package com;
public class withreturnwithoutarg {
	public static float div() {
		float a=10; float b=10000;
		float result=a%b;
		return result;
	}
	public static void main(String[] args) {
		float hy=div();
		System.out.println(hy);
		
	}

}
