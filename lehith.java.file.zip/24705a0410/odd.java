package com;

public class odd {
	public static void main(String[] args) {
		int a[]= {67,34,90,4,9,65,66};
		for(int i=0;i<=a.length-1;i++) {
			if(a[i]%1==0) {
				System.out.println("even elements"+a[i]);
			}
		}
	}

}
