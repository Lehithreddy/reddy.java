package com;

public class interfaceeeextendsdd {
	public void ee() {
		System.out.println("e");
	}

}
