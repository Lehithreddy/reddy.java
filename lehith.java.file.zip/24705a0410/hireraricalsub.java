package com;

public class hireraricalsub extends hireraricalsuper {
	public void car1() {
		System.out.println("bmw m3");
	
	

	}
	public static void main(String[] args) {
		hireraricalsub hs=new hireraricalsub();
		hs.car1();
		hs.car();
	}

}
