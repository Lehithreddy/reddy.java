package programs;
import java.util.Scanner;
public class alphabetornot {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		char ch=Sc.next().charAt(0);
		if(ch>='a' && ch<='z'||ch>='A' && ch<='Z') {
			System.out.println("given ch is alphabet");
		}
			
		
		else {
			System.out.println("given ch is not a alphabet");
		}
	}

}
