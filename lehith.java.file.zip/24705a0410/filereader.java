package com;

public class filereader {
public static void main(String[] args) {
		try {
			filereader fr=new filereader();
			for (int i=0;i<=((CharSequence) fr).length()-1;i++) {
				System.out.println((char) fr.read());
			}
		}
	
			catch(Exception e) {
				System.out.println("cannotread");
			}
		
	



}

private char read() {
	// TODO Auto-generated method stub
	return 0;
}
}


