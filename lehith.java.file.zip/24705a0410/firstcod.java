package com;

public class firstcod {
	public static void main(String[] arg) {
	System.out.println("hi bondalu");

}

}