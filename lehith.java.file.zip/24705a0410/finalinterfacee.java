package com;

public class finalinterfacee {
	
		public void a() {
			System.out.println("fff");
		}
		
			public void b() {
				System.out.println("ddddddd");
			}
			
				public void g() {
					System.out.println("vvvvvvvv");
				}
				public static void main(String[] args) {
					finalinterfacee f=new finalinterfacee();
					f.a();
					f.b();
					f.g();
				}
		

}
