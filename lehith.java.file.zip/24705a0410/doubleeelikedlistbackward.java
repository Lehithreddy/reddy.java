package com;
class nodal{
	int data;
	nodal next;
	nodal prev;
	nodal(int val){
		data=val;
		next=null;
		prev=null;
		
		
	}
}
	


public class doubleeelikedlistbackward {
	public static void backwardtraversal(nodal head) {
		nodal curr=head;
		while(curr!=null) {
			System.out.println(curr.data+" ");
			curr=curr.prev;
			
		}
		
		
	}
	public static void main(String[] args) {
		nodal head=new nodal(1);
		nodal second=new nodal(2);
		nodal third=new nodal(3);
		head.next=second;
		second.prev=head;
		second.next=third;
		third.prev=second;
		System.out.println("backward traversal:");
		backwardtraversal(head);
	}

}



