package com;
class Node{
	int data;
	Node next;
	Node prev;
	Node(int val){
		data=val;
		next=null;
		prev=null;
		
		
	}
}

public class doubleelinkedlist {
	static void forwardtraversal(Node head) {
		Node curr=head;
		while(curr!=null) {
			System.out.println(curr.data+" ");
			curr=curr.next;
			
		}
		System.out.println();
		
	}
	public static void main(String[] args) {
		Node head=new Node(1);
		Node second=new Node(2);
		Node third=new Node(3);
		head.next=second;
		second.prev=head;
		second.next=third;
		third.prev=second;
		System.out.println("forward traversal:");
		forwardtraversal(head);
	}

}
