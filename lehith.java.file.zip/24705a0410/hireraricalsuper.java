package com;
public class hireraricalsuper {
	public void car() {
		System.out.println("bmw m1");
		
	}
	public static void main(String[] args) {
		hireraricalsuper h=new hireraricalsuper();
		h.car();
	}
	

}
