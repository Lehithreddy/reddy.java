package com;

public class methodoverloading {
	public static void payment(int num,int cvv,int bal) {
		System.out.println("paid through debit card");
		
	}
	public static void payment(int num,int exp) {
		System.out.println("paid through credit card");
		
	}
	public static void payment(int num) {
		System.out.println("paid through cod");
		
	}
	public static void main(String[] args) {
		payment(655,87,8765);
		payment(98,2029);
		payment(450);
		
	}
	

}
