package com;

public class interfacea {
	public void a() {
	
	}

}
