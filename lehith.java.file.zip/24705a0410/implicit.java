package com;

public class implicit {
	public static void main(String[]arg) {
		short s=20;
		int a=s;
		System.out.println(a);
	}

}
