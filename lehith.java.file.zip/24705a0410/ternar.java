package com;

public class ternar{
	static int a=10;
	static int b=20;
	static String result = a > b ? "yes": "no";
	public static void main(Sring[]arg) {
	System.out.println(result);
	}


}
