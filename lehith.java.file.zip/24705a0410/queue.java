package com;
import java.util.LinkedList;
public class queue {
	public static void main(String[] args) {
		LinkedList<Integer>queue=new LinkedList<>();
		queue.add(10);
		queue.add(20);
		queue.add(30);
		System.out.println("queue:"+queue);
		System.out.println("top element:"+queue.peek());
		System.out.println("popped:"+queue.pop());
		System.out.println("queue after pop:"+queue);
		System.out.println("polled:"+queue.poll());
		System.out.println("queue after poll:"+queue);
		System.out.println("size:"+queue.size());
		System.out.println("is queue empty?"+queue.isEmpty());
		
	}

}
