package com;
public class mor {
	public void whatsappversion() {
		System.out.println("version only singleticks");
		
	}

}
