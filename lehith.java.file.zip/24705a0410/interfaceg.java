package com;

public class interfaceg extends interfaceb {
	public void g() {
		
	}

}
