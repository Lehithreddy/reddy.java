package com;

public class interfacecc {
	public void cc() {
	System.out.println("c");

}
}
