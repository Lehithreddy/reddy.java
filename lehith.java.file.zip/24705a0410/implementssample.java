package com;
public class implementssample {
	public void sample() {
		System.out.println("sample block");
		
	}
	public static void main(String[] args) {
	implementssample i=new implementssample();
		i.sample();
		
	}

}
