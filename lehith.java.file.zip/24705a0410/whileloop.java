package com;
import java.util.Scanner;
public class whileloop {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		int start=Sc.nextInt();
		int end=Sc.nextInt();
		while(start<=end) {
			System.out.println(start);
			start ++;
		}
		
	}

}
