a=2
b=4
 # addition
print ('Sum: ', a + b)
  # subtraction
print ('Subtraction: ', a - b)
 # multiplication
print ('Multiplication: ', a * b)
 # division
print ('Division: ', a /b)
